

component chart and Tree:-

![](/imges/photo_6201960182066557156_y.jpg)