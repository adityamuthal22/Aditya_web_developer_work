import logo from './logo.svg';
import './App.css';
import CartContainer from './components/CartContainer';

function App() {
  return (
    <div className="App">
    <CartContainer />
    </div>
  );
}

export default App;
